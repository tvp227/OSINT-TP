import tkinter as tk
import requests
from datetime import datetime
import webbrowser
from bs4 import BeautifulSoup
import sys
import os

# Vendor Capture

def vendor_flag_search(domain):
    api_key = "1f08d5da08c5d5ea80ebd9a8873d00a2024b7d7bf6c7e77096da3c0338dc3a0d"  # VT API key
    url = f"https://www.virustotal.com/api/v3/domains/{domain}"
    headers = {
        "x-apikey": api_key
    }

    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            vendor_flag_score = data["data"]["attributes"]["last_analysis_stats"]["malicious"]
            print(f"Vendor Flag Score for {domain}: {vendor_flag_score}")
        else:
            print("Error: Request failed.")
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")


def button1_clicked():
    if button1["bg"] == "black":
        button1["bg"] = "green"
    else:
        button1["bg"] = "black"

# DNS Capture

def dns_records_search(domain):
    api_key = "1f08d5da08c5d5ea80ebd9a8873d00a2024b7d7bf6c7e77096da3c0338dc3a0d"  # VT API key
    url = f"https://www.virustotal.com/api/v3/domains/{domain}"
    headers = {"x-apikey": api_key}

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        data = response.json()
        if "data" in data and "attributes" in data["data"]:
            dns_records = data["data"]["attributes"]["last_dns_records"]
            for record in dns_records:
                print(f"DNS Record: {record}")
        else:
            print(f"No DNS records found for {domain}")
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")

def button2_clicked():
    if button2["bg"] == "black":
        button2["bg"] = "green"
    else:
        button2["bg"] = "black"

# WHOIS Capture

def perform_whois_lookup(domain):
    api_key = "1f08d5da08c5d5ea80ebd9a8873d00a2024b7d7bf6c7e77096da3c0338dc3a0d"
    url = f"https://www.virustotal.com/api/v3/domains/{domain}"
    headers = {"x-apikey": api_key}

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        data = response.json()
        if "data" in data and "attributes" in data["data"]:
            whois_info = data["data"]["attributes"]["whois"]
            print(f"WHOIS Lookup for {domain}:\n{whois_info}")
        else:
            print(f"No WHOIS information found for {domain}")
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")

def button3_clicked():
    if button3["bg"] == "black":
        button3["bg"] = "green"
    else:
        button3["bg"] = "black"

# IP Abuse Report

def ip_abuse_report(ip):
    api_key = "696fd130c4e6beec11253d8545f356abf141f1b61525b30b68b520e742860dde35600c313eec3f66 "
    url = f"https://api.abuseipdb.com/api/v2/check?ipAddress={ip}&maxAgeInDays=90"
    headers = {
        "Key": api_key,
        "Accept": "application/json"
    }

    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            if "data" in data:
                abuse_report = data["data"]
                abuse_score = abuse_report.get("abuseConfidenceScore", "N/A")
                isp = abuse_report.get("isp", "N/A")
                usage_type = abuse_report.get("usageType", "N/A")
                hostnames = abuse_report.get("hostnames", [])
                domain = abuse_report.get("domain", "N/A")
                country = abuse_report.get("countryCode", "N/A")
                city = abuse_report.get("city", "N/A")

                print(f"IP Abuse Report for {ip}:")
                print(f"Abuse Score: {abuse_score}")
                print(f"ISP: {isp}")
                print(f"Usage Type: {usage_type}")
                print(f"Hostnames: {', '.join(hostnames)}")
                print(f"Domain: {domain}")
                print(f"Country: {country}")
                print(f"City: {city}")
            else:
                print(f"No abuse report found for {ip}")
        else:
            print("Error: Request failed.")
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")


def button4_clicked():
    if button4["bg"] == "black":
        button4["bg"] = "green"
    else:
        button4["bg"] = "black"

# URL2PNG implementation 

def button5_clicked():
    url = "https://www.url2png.com/"
    webbrowser.open_new(url)

# Google Search function

def google_search(domain):
    search_term = f"What is {domain}"
    api_key = "199f400acde13092947ed40f48b68ed69049b1a2b29a054cee812ef2ddbd746c" # Serpapi API key
    params = {
        "q": search_term,
        "api_key": api_key
    }

    try:
        response = requests.get("https://serpapi.com/search", params=params)
        if response.status_code == 200:
            data = response.json()
            if "organic_results" in data:
                organic_results = data["organic_results"]
                if organic_results:
                    first_result = organic_results[0]
                    title = first_result.get("title", "")
                    url = first_result.get("link", "")
                    snippet = first_result.get("snippet", "")
                    soup = BeautifulSoup(snippet, "html.parser")
                    description = soup.get_text(separator=" ")
                    print(f"Google search summary for {domain}:")
                    print(f"Title: {title}")
                    print(f"URL: {url}")
                    print(f"Description: {description}")
                else:
                    print(f"No summary found for {domain}")
            else:
                print("Error: Invalid response format.")
        else:
            print("Error: Request failed.")
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")

def button6_clicked():
    if button6["bg"] == "black":
        button6["bg"] = "green"
    else:
        button6["bg"] = "black"

# Generate a report

def generate_report(domain):
    report_filename = f"report_{domain}.txt"
    
    # Redirect standard output to a file
    with open(report_filename, "w") as report_file:
        sys.stdout = report_file
        
        print(f"--- OSINT Report for {domain} ---")
        print()

        # Vendor Flag Search
        vendor_flag_search(domain)
        print()

        # DNS Records Search
        dns_records_search(domain)
        print()

        # WHOIS Capture
        perform_whois_lookup(domain)
        print()

        # Google Search
        google_search(domain)
        print()

        # Restore standard output
        sys.stdout = sys.__stdout__

    print(f"Report generated successfully. Filename: {report_filename}")

def button7_clicked():
    domain = domain_entry.get()
    generate_report(domain)

# Execute button clicked

def execute_clicked():
    domain = domain_entry.get()
    if button1["bg"] == "green":
        vendor_flag_search(domain)
    if button2["bg"] == "green":
        dns_records_search(domain)
    if button3["bg"] == "green":
        perform_whois_lookup(domain)
    if button4["bg"] == "green":
        ip = ip_entry.get()
        ip_abuse_report(ip)
    if button6["bg"] == "green":
        google_search(domain)

# Create the main window
window = tk.Tk()
window.title("OSINT Quick Search")
window.geometry("580x420")
window.resizable(False, False)

# Set the background image
background_image = tk.PhotoImage(file="Prereq/background.png")
background_label = tk.Label(window, image=background_image)
background_label.place(x=0, y=0, relwidth=1, relheight=1)

# Create the domain input box
domain_label = tk.Label(window, text="Enter Domain:")
domain_label.place(x=50, y=50)

domain_entry = tk.Entry(window)
domain_entry.place(x=150, y=50, width=200)

# Create the IP input box
ip_label = tk.Label(window, text="Enter IP:")
ip_label.place(x=50, y=100)

ip_entry = tk.Entry(window)
ip_entry.place(x=150, y=100, width=200)

# Create the buttons
button1 = tk.Button(window, text="Vendor Flag Search", fg="white", bg="black", command=button1_clicked)
button1.place(x=50, y=150, width=200, height=30)

button2 = tk.Button(window, text="DNS Records", fg="white", bg="black", command=button2_clicked)
button2.place(x=50, y=200, width=200, height=30)

button3 = tk.Button(window, text="WHOIS", fg="white", bg="black", command=button3_clicked)
button3.place(x=50, y=250, width=200, height=30)

button4 = tk.Button(window, text="IP Abuse Report", fg="red", bg="black", command=button4_clicked)
button4.place(x=50, y=300, width=200, height=30)

button5 = tk.Button(window, text="URL2PNG", fg="black", bg="yellow", command=button5_clicked)
button5.place(x=300, y=200, width=200, height=30)

button6 = tk.Button(window, text="Google Search", fg="white", bg="black", command=button6_clicked)
button6.place(x=300, y=150, width=200, height=30)

button7 = tk.Button(window, text="Generate Report", fg="white", bg="blue", command=button7_clicked)
button7.place(x=300, y=250, width=200, height=30)

execute_button = tk.Button(window, text="Execute", fg="white", bg="green", command=execute_clicked)
execute_button.place(x=300, y=300, width=200, height=30)

window.mainloop()