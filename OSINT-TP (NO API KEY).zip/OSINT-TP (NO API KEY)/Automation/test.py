import tkinter as tk
import requests
from datetime import datetime
import webbrowser
from bs4 import BeautifulSoup
import sys
import os

# Vendor Capture

def vendor_flag_search(domain, report_file):
    api_key = "1f08d5da08c5d5ea80ebd9a8873d00a2024b7d7bf6c7e77096da3c0338dc3a0d"  # VT API key
    url = f"https://www.virustotal.com/api/v3/domains/{domain}"
    headers = {
        "x-apikey": api_key
    }

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raise an exception if the request was not successful
        data = response.json()
        vendor_flag_score = data["data"]["attributes"]["last_analysis_stats"]["malicious"]
        report_file.write(f"Vendor Flag Score for {domain}: {vendor_flag_score}\n")
    except requests.exceptions.RequestException as e:
        report_file.write(f"Error: {e}\n")
    except (KeyError, ValueError):
        report_file.write(f"No vendor information found for {domain}\n")

def button1_clicked():
    if button1["bg"] == "black":
        button1["bg"] = "green"
    else:
        button1["bg"] = "black"

# DNS Capture

def dns_records_search(domain):
    api_key = "1f08d5da08c5d5ea80ebd9a8873d00a2024b7d7bf6c7e77096da3c0338dc3a0d"  # VT API key
    url = f"https://www.virustotal.com/api/v3/domains/{domain}"
    headers = {"x-apikey": api_key}

    dns_records = []  # Store DNS records in a list

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raise an exception if the request was not successful
        data = response.json()
        if "data" in data and "attributes" in data["data"]:
            records = data["data"]["attributes"]["last_dns_records"]
            for record in records:
                dns_type = record.get("type", "N/A")
                value = record.get("value", "N/A")
                ttl = record.get("ttl", "N/A")
                dns_records.append((dns_type, ttl, value))  # Add the record to the list
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")

    return dns_records

def button2_clicked():
    if button2["bg"] == "black":
        button2["bg"] = "green"
    else:
        button2["bg"] = "black"

# WHOIS Capture

def perform_whois_lookup(domain, report_file=None):
    api_key = "1f08d5da08c5d5ea80ebd9a8873d00a2024b7d7bf6c7e77096da3c0338dc3a0d"
    url = f"https://www.virustotal.com/api/v3/domains/{domain}"
    headers = {"x-apikey": api_key}

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raise an exception if the request was not successful
        data = response.json()
        if "data" in data and "attributes" in data["data"]:
            whois_info = data["data"]["attributes"]["whois"]
            if report_file:
                report_file.write(f"<pre>{whois_info}</pre>\n")
            else:
                print(f"WHOIS Lookup for {domain}:\n{whois_info}")
        else:
            if report_file:
                report_file.write("<p>No WHOIS information found for this domain.</p>\n")
            else:
                print(f"No WHOIS information found for {domain}")
    except requests.exceptions.RequestException as e:
        if report_file:
            report_file.write(f"<p>Error: {e}</p>\n")
        else:
            print(f"Error: {e}")

def button3_clicked():
    if button3["bg"] == "black":
        button3["bg"] = "green"
    else:
        button3["bg"] = "black"

# IP Abuse Report

def ip_abuse_report(ip, report_file):
    api_key = "696fd130c4e6beec11253d8545f356abf141f1b61525b30b68b520e742860dde35600c313eec3f66 "
    url = f"https://api.abuseipdb.com/api/v2/check?ipAddress={ip}&maxAgeInDays=90"
    headers = {
        "Key": api_key,
        "Accept": "application/json"
    }

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raise an exception if the request was not successful
        data = response.json()
        if "data" in data:
            abuse_report = data["data"]
            abuse_score = abuse_report.get("abuseConfidenceScore", "N/A")
            isp = abuse_report.get("isp", "N/A")
            usage_type = abuse_report.get("usageType", "N/A")
            hostnames = abuse_report.get("hostnames", [])
            domain = abuse_report.get("domain", "N/A")
            country = abuse_report.get("countryCode", "N/A")
            city = abuse_report.get("city", "N/A")

            report_file.write(f"IP Abuse Report for {ip}:\n")
            report_file.write(f"Abuse Score: {abuse_score}\n")
            report_file.write(f"ISP: {isp}\n")
            report_file.write(f"Usage Type: {usage_type}\n")
            report_file.write(f"Hostnames: {', '.join(hostnames)}\n")
            report_file.write(f"Domain: {domain}\n")
            report_file.write(f"Country: {country}\n")
            report_file.write(f"City: {city}\n")
        else:
            report_file.write(f"No abuse report found for {ip}\n")
    except requests.exceptions.RequestException as e:
        report_file.write(f"Error: {e}\n")

def button4_clicked():
    if button4["bg"] == "black":
        button4["bg"] = "green"
    else:
        button4["bg"] = "black"

# URL2PNG implementation 

def button5_clicked():
    url = "https://www.url2png.com/"
    webbrowser.open_new(url)

# Google Search function

def google_search(domain, report_file):
    search_term = f"What is {domain}"
    api_key = "199f400acde13092947ed40f48b68ed69049b1a2b29a054cee812ef2ddbd746c" # Serpapi API key
    params = {
        "q": search_term,
        "api_key": api_key
    }

    try:
        response = requests.get("https://serpapi.com/search", params=params)
        response.raise_for_status()  # Raise an exception if the request was not successful
        data = response.json()
        if "organic_results" in data:
            organic_results = data["organic_results"]
            if organic_results:
                first_result = organic_results[0]
                title = first_result.get("title", "")
                url = first_result.get("link", "")
                snippet = first_result.get("snippet", "")
                soup = BeautifulSoup(snippet, "html.parser")
                description = soup.get_text(separator=" ")
                report_file.write(f"Google search summary for {domain}:\n")
                report_file.write(f"Title: {title}\n")
                report_file.write(f"URL: {url}\n")
                report_file.write(f"Description: {description}\n")
            else:
                report_file.write(f"No summary found for {domain}\n")
        else:
            report_file.write("Error: Invalid response format.\n")
    except requests.exceptions.RequestException as e:
        report_file.write(f"Error: {e}\n")

def button6_clicked():
    if button6["bg"] == "black":
        button6["bg"] = "green"
    else:
        button6["bg"] = "black"

# Google Image Search 

images_api_key ="AIzaSyBWjrOdZPsnXcTrom1NikBoRbri9fbo8zY"

def google_images_search(domain):
    search_term = f"{domain} logo"
    search_url = f"https://www.googleapis.com/customsearch/v1"
    params = {
        "key": images_api_key,
        "cx": "271426e1b03bb4534",  # Replace with your search engine ID
        "q": search_term,
        "searchType": "image"
    }

    try:
        response = requests.get(search_url, params=params)
        response.raise_for_status()
        data = response.json()
        if "items" in data:
            image_urls = [item["link"] for item in data["items"]]
            return image_urls
        else:
            return []
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")
        return []


# MD5 Vendor Search

def md5_vendor_search(md5, report_file):
    api_key = "1f08d5da08c5d5ea80ebd9a8873d00a2024b7d7bf6c7e77096da3c0338dc3a0d"  # VT API key
    url = f"https://www.virustotal.com/api/v3/files/{md5}"
    headers = {
        "x-apikey": api_key
    }

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raise an exception if the request was not successful
        data = response.json()
        if "data" in data:
            vendors = data["data"]["attributes"]["last_analysis_results"]
            report_file.write(f"Vendor search results for MD5 {md5}:\n")
            for vendor, result in vendors.items():
                category = result.get("category", "N/A")
                report_file.write(f"{vendor}: {category}\n")
        else:
            report_file.write(f"No vendor information found for MD5 {md5}\n")
    except requests.exceptions.RequestException as e:
        report_file.write(f"Error: {e}\n")

def button8_clicked():
    if button8["bg"] == "black":
        button8["bg"] = "green"
    else:
        button8["bg"] = "black"

# Generate a report

def generate_report(domain):
    report_filename = f"report_{domain}.html"
    vendor_score = 0  # Initialize with a default value

    # Create the HTML report
    with open(report_filename, "w") as report_file:
        report_file.write(f"<!DOCTYPE html>\n<html>\n<head>\n<title>OSINT Report for {domain}</title>\n</head>\n<body>\n")
        report_file.write(f"<h1>--- OSINT Report for {domain} ---</h1>\n")
        report_file.write("<br/>\n")

        # Vendor Flag Search
        report_file.write("<h2>Vendor Flag Search</h2>\n")
        vendor_flag_search(domain, report_file)
        report_file.write("<br/>\n")

        # DNS Records Search
        report_file.write("<h2>DNS Records Search</h2>\n")
        dns_records = dns_records_search(domain)
        if dns_records:
            report_file.write("<ul>\n")
            for dns_record in dns_records:
                dns_type, ttl, value = dns_record
                report_file.write(f"<li>{dns_type}<br/>{ttl}<br/>{value}</li>\n")
            report_file.write("</ul>\n")
        else:
            report_file.write("<p>No DNS records found for this domain.</p>\n")
        report_file.write("<br/>\n")

        # WHOIS Capture
        report_file.write("<h2>WHOIS Capture</h2>\n")
        perform_whois_lookup(domain, report_file)
        report_file.write("<br/>\n")

        # Google Search
        report_file.write("<h2>Google Search</h2>\n")
        google_search(domain, report_file)
        report_file.write("<br/>\n")

        # Google Images Search
        report_file.write("<h2>Google Images</h2>\n")
        image_urls = google_images_search(domain)
        if image_urls:
            report_file.write("<ul>\n")
            for image_url in image_urls:
                report_file.write(f"<li><img src='{image_url}' alt='Google Image' width='200'></li>\n")
            report_file.write("</ul>\n")
        else:
            report_file.write("<p>No Google Images found for this domain.</p>\n")
        report_file.write("<br/>\n")

        # Analyze results and add a summary
        report_file.write("<h2>Summary</h2>\n")

        # ... (other tasks' analysis and summary can be added here) ...

        report_file.write("</body>\n</html>")

    print(f"HTML Report generated successfully. Filename: {report_filename}")

def button7_clicked():
    domain = domain_entry.get()
    generate_report(domain)

# Execute button clicked

def execute_clicked():
    domain = domain_entry.get()
    md5_process = md5_entry.get()

    if md5_process:
        if button1["bg"] == "green":
            vendor_flag_search(md5_process)
        if button6["bg"] == "green":
            google_search(md5_process)
        md5_vendor_search(md5_process)
    else:
        if button1["bg"] == "green":
            vendor_flag_search(domain)
        if button2["bg"] == "green":
            dns_records_search(domain)
        if button3["bg"] == "green":
            perform_whois_lookup(domain)
        if button4["bg"] == "green":
            ip = ip_entry.get()
            ip_abuse_report(ip)
        if button6["bg"] == "green":
            google_search(domain)

# Create the main window
window = tk.Tk()
window.title("OSINT Quick Search")
window.geometry("700x430")
window.resizable(False, False)

# Set the background image
background_image = tk.PhotoImage(file="Prereq/background.png")
background_label = tk.Label(window, image=background_image)
background_label.place(x=0, y=0, relwidth=1, relheight=1)

# Create the domain input box
domain_label = tk.Label(window, text="Enter Domain:")
domain_label.place(x=50, y=50)

domain_entry = tk.Entry(window)
domain_entry.place(x=150, y=50, width=200)

# Create the IP input box
ip_label = tk.Label(window, text="Enter IP:")
ip_label.place(x=50, y=100)

ip_entry = tk.Entry(window)
ip_entry.place(x=150, y=100, width=200)

# Create the MD5/process input box
md5_label = tk.Label(window, text="MD5/Process:")
md5_label.place(x=50, y=150)

md5_entry = tk.Entry(window)
md5_entry.place(x=150, y=150, width=200)

# Create the buttons
button1 = tk.Button(window, text="Vendor Flag Search", fg="white", bg="black", command=button1_clicked)
button1.place(x=50, y=200, width=200)

button2 = tk.Button(window, text="DNS Records", fg="white", bg="black", command=button2_clicked)
button2.place(x=50, y=250, width=200)

button3 = tk.Button(window, text="WHOIS", fg="white", bg="black", command=button3_clicked)
button3.place(x=50, y=300, width=200)

button4 = tk.Button(window, text="IP Abuse Report", fg="red", bg="black", command=button4_clicked)
button4.place(x=50, y=350, width=200)

button5 = tk.Button(window, text="URL2PNG", fg="black", bg="yellow", command=button5_clicked)
button5.place(x=300, y=250, width=200)

button6 = tk.Button(window, text="Google Search", fg="white", bg="black", command=button6_clicked)
button6.place(x=300, y=200, width=200)

button7 = tk.Button(window, text="Generate Report", fg="white", bg="blue", command=button7_clicked)
button7.place(x=300, y=300, width=200)

button8 = tk.Button(window, text="MD5 Vendor Search", fg="red", bg="black", command=button8_clicked)
button8.place(x=300, y=350, width=200)

execute_button = tk.Button(window, text="Execute", fg="white", bg="green", command=execute_clicked)
execute_button.place(x=550, y=275, width=100)

window.mainloop()
